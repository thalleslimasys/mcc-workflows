from django.apps import AppConfig


class MccWorkflowsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "workflows"
    is_arches_application = True
